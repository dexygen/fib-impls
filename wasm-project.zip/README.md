# Empty AssemblyScript Project
